package SrikantTestingCoaching;

public class OddEvenTest{


    public static void main(String[] args) {

       int x = 21;

       if ( x % 2 == 0){

           System.out.println(x +" is Even Number");

       } else {

           System.out.println(x +" is Odd Number");
       }


        }

    }

