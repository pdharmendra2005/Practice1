package SrikantTestingCoaching;

public class Clac2 {
    public static void main(String[] args) {
        Clac1 m1 = new Clac1();

        System.out.println("Print the value of x =" + m1.x);
        System.out.println("Print the value of y =" + m1.y);
        System.out.println("Print the value of z =" + m1.z);
        System.out.println("Print the value of f =" + m1.f);
        System.out.println("Print the value of d =" + m1.d);
        System.out.println("Print the value of s =" + m1.s);





            }
}
