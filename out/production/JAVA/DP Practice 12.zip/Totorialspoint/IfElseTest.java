package Totorialspoint;

public class IfElseTest {

    public static void main(String args[]) {
        int x = 30;

        if( x > 20 ) {
            System.out.print("This is if statement");
        }//else {
        System.out.print("\n");

        System.out.print("This is else statement");
        //}
    }
}