package SrikantTestingCoaching.methodwithargs;

public class MaximumMin {

   /* public void InputNum(int x, int y){

        if {
            x
        }
    }*/

    public static void main(String[] args) {

        int MaxNum = Math.max(5, 25);
        System.out.println(MaxNum);
    }
}
