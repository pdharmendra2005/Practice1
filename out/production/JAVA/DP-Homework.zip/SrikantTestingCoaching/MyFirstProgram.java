package SrikantTestingCoaching;

public class MyFirstProgram {
    public static void main(String[] args) {
        int age = 4;
        long weight = 45L;
        float height = 3.4f;
        char gender = 'M';
        String name = "QA-Masters";
        boolean status = true;
        System.out.println("Welcome to JAVA World");
        System.out.println(age);
        System.out.println(weight);
        System.out.println(height);
        System.out.println(gender);
        System.out.println(name);
        System.out.println(status);
    }
}
