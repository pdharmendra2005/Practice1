package Javapoint;

abstract class RbiBank{

    abstract int rateOfInterest();

}
class Sbi extends RbiBank{
    int rateOfInterest(){
        return 7;
    }
}
class PNB extends RbiBank{
    int rateOfInterest(){
        return 4;
    }
}


public class AbstractTestBank {
}
