package Javapoint;

abstract class BikeCompany{
    BikeCompany(){
        System.out.println("Bike is Created");
    }
    abstract void run();
    void changeGear(){
        System.out.println("Gear is Changed");
    }
}
class Honda extends BikeCompany{

    void run() {
        System.out.println("Honda is running");
    }
    void changeGear(){
        System.out.println(" Honda gear has changed");
    }
}
class Bajaj extends BikeCompany{
    void run(){
        System.out.println("Bajaj is running");
    }
    void changeGear(){
        System.out.println("Bajaj gear has changed");
    }
    int  BajajValue(){
        return 14000;
    }
}


public class AbstractTestBike {

    public static void main(String[] args) {
        BikeCompany bikeCompany = new Honda();
        bikeCompany.run();
        bikeCompany.changeGear();

        Bajaj bajaj = new Bajaj();
        bajaj.run();
        bajaj.changeGear();
        System.out.println("Price of bajaj is " +bajaj.BajajValue());

    }


}



