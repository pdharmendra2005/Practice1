package SrikantTestingCoaching;

public class MethodPrac1 {

    void addition() {
        int p=500 , q=700 , r ;
        r = p + q ;
        System.out.println("Simple addition p + q is :" + r);

    }
    void substraction(){
        int m = 350 , n= 200, t ;
        t = m - n ;
        System.out.println("Simple multiplication m x n is :" + t);
    }
    void multiplication(){
        float f = 3.5f, g = 4.5f , h;
        h = f * g;
        System.out.println("Simple multiplication f * g is :"+ h);

    }

}
