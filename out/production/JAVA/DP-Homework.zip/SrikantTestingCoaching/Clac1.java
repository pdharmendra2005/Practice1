package SrikantTestingCoaching;

public class Clac1 {
    int x=100, y=150, z;
    float f= 3.5f;
    char c= 'M';
    double d= 3.54d;
    String s = " My practice"; // Que 1: Why S is only in Capital ??



}
