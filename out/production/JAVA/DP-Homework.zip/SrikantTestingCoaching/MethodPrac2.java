package SrikantTestingCoaching;

public class MethodPrac2 {

    public static void main(String[] args) {
        MethodPrac1 mp1 = new MethodPrac1();
        mp1.addition();
        mp1.substraction();
        mp1.multiplication();
        // Que: Can we create Object outside of the main method?
    }

}
