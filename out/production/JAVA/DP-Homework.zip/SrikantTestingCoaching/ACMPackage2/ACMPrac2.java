package SrikantTestingCoaching.ACMPackage2;


import SrikantTestingCoaching.ACMPackage1.ACMPrac1;

public class ACMPrac2 {
    public static void main(String[] args) {
        ACMPrac1 ac1 = new ACMPrac1();
        ac1.addition();
        ac1.substraction();
        //ac1.m can't excess as private variable
    }
}
