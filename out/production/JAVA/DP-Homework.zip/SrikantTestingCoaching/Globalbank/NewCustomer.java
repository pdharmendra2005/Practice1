package SrikantTestingCoaching.Globalbank;

public class NewCustomer {

    int x = 70;

    public void age(){
        int a = 18, b = 21;
        System.out.println(a);
    }
    public void nationality(){
        String CountryName = " Local Resident";
        System.out.println(CountryName);
    }
    private void nationality1(){
        String CountryName1 = "UK resident";
        System.out.println(CountryName1);
    }


}

