package SrikantTestingCoaching;

public class VariablePrac1{
    int x=15,y=10 ;
    int z=x+y;


    public static void main (String[] args) {
        VariablePrac1 Var1=new VariablePrac1();
        //Created Instance Var1
        System.out.println(Var1.z);
    }
}

